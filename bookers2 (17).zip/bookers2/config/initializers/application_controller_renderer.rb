# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '24eda738cc1c41816d76c5a5ecd8175e11cffd1915304df4e29b378f694a204fe7183ef351b0bf5ba2a7a8a047b6fde521c74d8b106df4697cb432646fe7b24f'